//
//  Database.swift
//  Movie
//
//  Created by Maurício Cantuária on 16/05/22.
//

import Foundation
import SwiftKuery

class Filmes: Table {
    let tableName = "Filme"
    let idFilme = Column("idFilme", Int32.self, autoIncrement: true, primaryKey: true, notNull: true)
    let nome = Column("nome", String.self, notNull: true)
}
class Elencos: Table {
    let tableName = "Elenco"
    let idElenco = Column("idElenco", Int32.self, autoIncrement: true, primaryKey: true, notNull: true)
    let nome = Column("nome", String.self, notNull: true)
}

