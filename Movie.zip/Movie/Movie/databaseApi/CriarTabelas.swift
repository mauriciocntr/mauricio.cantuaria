//
//  CriarTabelas.swift
//  Movie
//
//  Created by Maurício Cantuária on 16/05/22.
//

import Foundation
import SwiftKuery

func criaTabelas() {
    let utils = CommonUtils.sharedInstance
    
    let filmes = Filmes()
    utils.criaTabela(filmes)
    print("Tabela Filmes criada")
    
    let elencos = Elencos()
    utils.criaTabela(elencos)
    print("Tabela Elenco criada")


}
