//
//  Consultas.swift
//  Movie
//
//  Created by Maurício Cantuária on 26/05/22.
//

import Foundation
import SwiftKuery

public extension String {
    func fill(to: Int = 20) -> String {
var saida = self
if self.count < to {
for _ in 0..<(to - self.count) {
saida += " "
}
}
return saida
}
}
func consulta(_ select: Select) {
let utils = CommonUtils.sharedInstance
utils.executaConsulta(select) { registros in
guard let registros = registros else {
return print("Sem registros")
}
registros.forEach { linha in
linha.forEach { item in
print("\(item ?? "")".fill(), terminator:
" ")
}
print()
}
}
}

func consulta1() {
    let filmes = Filmes()


consulta(Select(filmes.nome, from: filmes)
    .leftJoin(filmes)
        .on(filmes.idFilme == filmes.idFilme))
}
