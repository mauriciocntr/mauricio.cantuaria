//
//  AlterarEstilo.swift
//  Movie
//
//  Created by Maurício Cantuária on 26/05/22.
//

import Foundation
import SwiftKuery

func atualizaFilme() {
    let utils = CommonUtils.sharedInstance

    let filmes = Filmes()

func imprime() {
        print("""
        \("Filme".fill()) \("Elenco".fill())
-------------------- -------------------- --------------------
""")

    consulta(Select(filmes.nome, filmes.nome, from: filmes)
    .join(filmes).on(filmes.idFilme == filmes.idFilme)
    .join(filmes).on(filmes.idFilme == filmes.idFilme)
    .where(filmes.idFilme == 3))
}

imprime()
print("\n- - - - - - - - - - - - - - - - - - - - - - - - \n")

utils.executaQuery(Update(filmes, set: [(filmes.idFilme, 2)], where: filmes.idFilme == 3))

imprime()
print()
}

