//
//  RemoveTabelas.swift
//  Movie
//
//  Created by Maurício Cantuária on 26/05/22.
//

import Foundation
import SwiftKuery

func removeTabelas() {

let utils = CommonUtils.sharedInstance


for tabela in [
Filmes()
]{

print("Apagando \(tabela.nameInQuery)")
    utils.removeTabela(tabela)

}
print("Todas as tabelas foram removidas")

}
