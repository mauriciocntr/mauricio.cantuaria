//
//  Model.swift
//  Movie
//
//  Created by Maurício Cantuária on 24/05/22.
//

import Foundation

struct Filme {
var idFilme: Int
var nome: String
var colunas: [Any] { [ idFilme, nome ] }
}
struct Elenco {
var idElenco: Int
var nome: String
var colunas: [Any] { [ idElenco, nome ] }
}
