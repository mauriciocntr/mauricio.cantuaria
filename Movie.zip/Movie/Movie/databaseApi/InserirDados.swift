//
//  InserirDados.swift
//  Movie
//
//  Created by Maurício Cantuária on 26/05/22.
//

import Foundation
import SwiftKuery

func insereDados() {
    let utils = CommonUtils.sharedInstance

    let filmes = [
        Filme(idFilme: 1, nome: "Vingadores"),
        Filme(idFilme: 2, nome: "Hulk")
    ]
    
    utils.executaQuery(Insert(into: Filmes(), rows: filmes.map{ $0.colunas }))
    print("Os registros de Filmes foram inseridos")

    let elencos = [
        Elenco(idElenco: 1, nome: "Robert John Downey Jr., Scarlett Johansson, Chris Evans"),
        Elenco(idElenco: 2, nome: "Eric Bana, Jennifer Connelly, Kevin Rankin")
    ]
    
    utils.executaQuery(Insert(into: Elencos(), rows: elencos.map{ $0.colunas }))
    print("Os registros de Elencos foram inseridos")
}
