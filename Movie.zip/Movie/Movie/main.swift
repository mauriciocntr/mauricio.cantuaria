//
//  main.swift
//  Movie
//
//  Created by Maurício Cantuária on 16/05/22.
//

import Foundation

//criaTabelas()
//insereDados()
//consulta1()
atualizaFilme()
