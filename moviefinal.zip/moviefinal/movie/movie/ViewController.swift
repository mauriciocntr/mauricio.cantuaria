//
//  ViewController.swift
//  movie
//
//  Created by Maurício Cantuária on 29/07/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

